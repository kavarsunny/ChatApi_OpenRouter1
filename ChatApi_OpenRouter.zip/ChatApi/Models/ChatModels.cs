namespace ChatApi.Models;

public record ChatMessage(string Role, string Content);

public record ChatRequest(IReadOnlyList<ChatMessage> Messages);

public record ChatResponse(string Reply);
