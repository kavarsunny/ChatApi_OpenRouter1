namespace ChatApi.Services;

public class OpenRouterOptions
{
    public const string SectionName = "OpenRouter";

    public string ApiKey { get; set; } = string.Empty;
    public string Model { get; set; } = "openai/gpt-4o-mini";

    // Optional but recommended by OpenRouter for attribution/rankings.
    public string? SiteUrl { get; set; }
    public string? SiteName { get; set; }
}
