using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using ChatApi.Models;
using Microsoft.Extensions.Options;

namespace ChatApi.Services;

public class OpenRouterChatService : IOpenRouterChatService
{
    private const string Endpoint = "https://openrouter.ai/api/v1/chat/completions";

    private readonly HttpClient _httpClient;
    private readonly OpenRouterOptions _options;

    public OpenRouterChatService(HttpClient httpClient, IOptions<OpenRouterOptions> options)
    {
        _httpClient = httpClient;
        _options = options.Value;
    }

    public async Task<string> GetReplyAsync(
        IReadOnlyList<ChatMessage> messages,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(_options.ApiKey))
        {
            throw new InvalidOperationException(
                "OpenRouter API key is not configured. Set OpenRouter:ApiKey in appsettings or user secrets.");
        }

        var request = new OpenRouterChatRequest
        {
            Model = _options.Model,
            Messages = messages.Select(MapMessage).ToList()
        };

        using var httpRequest = new HttpRequestMessage(HttpMethod.Post, Endpoint)
        {
            Content = JsonContent.Create(request)
        };

        httpRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _options.ApiKey);

        // Optional headers OpenRouter uses for attribution / rankings on openrouter.ai.
        if (!string.IsNullOrWhiteSpace(_options.SiteUrl))
        {
            httpRequest.Headers.Add("HTTP-Referer", _options.SiteUrl);
        }

        if (!string.IsNullOrWhiteSpace(_options.SiteName))
        {
            httpRequest.Headers.Add("X-Title", _options.SiteName);
        }

        using var response = await _httpClient.SendAsync(httpRequest, cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            var errorBody = await response.Content.ReadAsStringAsync(cancellationToken);
            throw new HttpRequestException(FormatOpenRouterError((int)response.StatusCode, errorBody));
        }

        var payload = await response.Content.ReadFromJsonAsync<OpenRouterChatResponse>(
            cancellationToken: cancellationToken);

        var text = payload?.Choices?
            .FirstOrDefault()?
            .Message?
            .Content;

        if (string.IsNullOrWhiteSpace(text))
        {
            throw new InvalidOperationException("OpenRouter API returned an empty response.");
        }

        return text.Trim();
    }

    private static string FormatOpenRouterError(int statusCode, string errorBody)
    {
        try
        {
            using var document = JsonDocument.Parse(errorBody);
            var message = document.RootElement
                .GetProperty("error")
                .GetProperty("message")
                .GetString();

            if (!string.IsNullOrWhiteSpace(message))
            {
                return $"OpenRouter API returned {statusCode}: {message}";
            }
        }
        catch (JsonException)
        {
            // Fall back to the raw response below.
        }

        return $"OpenRouter API returned {statusCode}: {errorBody}";
    }

    private static OpenRouterMessage MapMessage(ChatMessage message)
    {
        var role = message.Role.ToLowerInvariant() switch
        {
            "assistant" => "assistant",
            "user" => "user",
            "system" => "system",
            _ => throw new ArgumentException($"Unsupported role: {message.Role}")
        };

        return new OpenRouterMessage
        {
            Role = role,
            Content = message.Content
        };
    }

    private sealed class OpenRouterChatRequest
    {
        [JsonPropertyName("model")]
        public string Model { get; set; } = string.Empty;

        [JsonPropertyName("messages")]
        public List<OpenRouterMessage> Messages { get; set; } = [];
    }

    private sealed class OpenRouterMessage
    {
        [JsonPropertyName("role")]
        public string Role { get; set; } = "user";

        [JsonPropertyName("content")]
        public string Content { get; set; } = string.Empty;
    }

    private sealed class OpenRouterChatResponse
    {
        [JsonPropertyName("choices")]
        public List<OpenRouterChoice>? Choices { get; set; }
    }

    private sealed class OpenRouterChoice
    {
        [JsonPropertyName("message")]
        public OpenRouterMessage? Message { get; set; }
    }
}
