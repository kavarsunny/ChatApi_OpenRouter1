using ChatApi.Models;

namespace ChatApi.Services;

public interface IOpenRouterChatService
{
    Task<string> GetReplyAsync(IReadOnlyList<ChatMessage> messages, CancellationToken cancellationToken = default);
}
