import { Component, ElementRef, ViewChild, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ChatMessage } from '../models/chat.models';
import { ChatService } from '../services/chat.service';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './chat.component.html',
  styleUrl: './chat.component.scss'
})
export class ChatComponent {
  @ViewChild('messagesEnd') private messagesEnd?: ElementRef<HTMLDivElement>;

  readonly messages = signal<ChatMessage[]>([
    {
      role: 'assistant',
      content: 'Hello! I am your AI assistant, powered by OpenRouter. Ask me anything to get started.'
    }
  ]);

  draft = '';
  isLoading = false;
  errorMessage = '';

  constructor(private readonly chatService: ChatService) {}

  sendMessage(): void {
    const content = this.draft.trim();
    if (!content || this.isLoading) {
      return;
    }

    const nextMessages: ChatMessage[] = [
      ...this.messages(),
      { role: 'user', content }
    ];

    this.messages.set(nextMessages);
    this.draft = '';
    this.isLoading = true;
    this.errorMessage = '';
    this.scrollToBottom();

    this.chatService.sendMessage({ messages: nextMessages }).subscribe({
      next: (response) => {
        this.messages.update((messages) => [
          ...messages,
          { role: 'assistant', content: response.reply }
        ]);
        this.isLoading = false;
        this.scrollToBottom();
      },
      error: (error) => {
        this.isLoading = false;
        this.errorMessage =
          error?.error?.error ??
          'Something went wrong while talking to the assistant.';
      }
    });
  }

  onKeyDown(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.sendMessage();
    }
  }

  private scrollToBottom(): void {
    setTimeout(() => {
      this.messagesEnd?.nativeElement.scrollIntoView({ behavior: 'smooth' });
    });
  }
}
